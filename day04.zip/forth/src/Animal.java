public class Animal {
    public Animal(){
        System.out.println("我是动物");
    }
}
