// Dog.java
public class Dog extends Animal {
    public Dog(){
        System.out.println("我是狗");
    }
}
