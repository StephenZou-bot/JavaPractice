package MyFirstJava;

public class AverageScore {
    public static void main(String[] args) {
        int[] data = {61, 57, 95, 85, 75, 65, 44, 66, 90, 32};
        int sum = 0;
        for (int datum : data) {
            sum += datum;
        }
        System.out.println("AverageScore:"+ sum / data.length);
    }
}
