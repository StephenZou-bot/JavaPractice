package MyFirstJava;
import java.util.Scanner;

public class StringUtil {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String a = in.nextLine();
        StringBuilder stringBuilder = new StringBuilder(a);
        for (int i = 0; i < stringBuilder.length();i++){
            if (stringBuilder.charAt(i)==' '){
                stringBuilder.deleteCharAt(i);
                i--;
            }
        }
        System.out.println(stringBuilder.toString());
    }
}
