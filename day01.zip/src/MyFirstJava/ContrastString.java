package MyFirstJava;
import java.util.Scanner;

public class ContrastString {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String a = in.nextLine();
        String b = in.nextLine();
        boolean c = a.equalsIgnoreCase(b);
        if (c) {
            System.out.println("相同");
        } else {
            System.out.println("不同");
        }
    }
}
