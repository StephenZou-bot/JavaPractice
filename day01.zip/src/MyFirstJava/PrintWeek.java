package MyFirstJava;
import java.util.Scanner;

public class PrintWeek {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        switch (x) {
            case 1 -> System.out.println("今天是星期一");
            case 2 -> System.out.println("今天是星期二");
            case 3 -> System.out.println("今天是星期三");
            case 4 -> System.out.println("今天是星期四");
            case 5 -> System.out.println("今天是星期五");
            case 6 -> System.out.println("今天是星期六");
            case 7 -> System.out.println("今天是星期天");
            default -> System.out.println("没有此星期哦！");
        }
    }
}
