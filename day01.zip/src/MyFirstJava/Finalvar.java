package MyFirstJava;

public class Finalvar {
    public static void main(String[] args) {
        final String FINAL_STRING="I LOVE YOU";
        System.out.println(FINAL_STRING);
    }
}
