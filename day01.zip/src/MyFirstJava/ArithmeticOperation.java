package MyFirstJava;

public class ArithmeticOperation {
    public static void main(String[] args) {
        int a = 5;
        int b = 3;
        int c = 3;
        int d = 3;
        System.out.println("a + b = " + (a + b));
        System.out.println("a - b = " + (a - b));
        System.out.println("a * b = " + (a * b));
        System.out.println("a / b = " + (a / b));
        System.out.println("a % b = " + (a % b));
        System.out.println("a++ = " + (a++));
        System.out.println("++a = " + (++a));
        System.out.println("b-- = " + (b--));
        System.out.println("--b = " + (--b));
        System.out.println("c++ = " + (c++));
        System.out.println("d++ ="  + (d++));
        System.out.println("++d = " + (++d));
    }
}
