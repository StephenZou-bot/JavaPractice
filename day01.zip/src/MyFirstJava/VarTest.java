package MyFirstJava;

public class VarTest {
    public static void main(String[] args) {
        System.out.println("Define a variable a is");
        int a;
        a = 5;
        System.out.println(a);
    }
}
