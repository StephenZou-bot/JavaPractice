package MyFirstJava;

public class MethodDemo {
    public static void main(String[] args) {
        method();
    }

    public static void method(){
        System.out.println("Hello");

    }
}
