package MyFirstJava;

public class Test {
    public static void main(String[] args) {
        int [] a1 = {1,2,3};
        int [] a2;
        a2 = a1;
        for(int i = 0; i < a2.length; i++){
            a2[i]++;
        }
        for (int j : a1) {
            System.out.println(j);
        }
    }
}
