import java.util.Arrays;

public class SystemTest {
    public static void main(String[] args) {
        int[] a = {7, 8, 9, 10, 11};
        int[] b = {1, 2, 3, 4, 5, 6};
        System.arraycopy(a, 2, b, 2, 3);
        System.out.println(Arrays.toString(b));
        System.out.println("java安装路径："+System.getProperty("java.home"));
    }
}
