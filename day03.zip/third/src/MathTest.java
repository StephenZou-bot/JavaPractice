public class MathTest {
    public static void main(String[] args) {
        double a = Math.random();
        double b = Math.random();
        System.out.println(a);
        System.out.println(b);
        System.out.println("大的为："+Math.max(a,b));
    }
}
