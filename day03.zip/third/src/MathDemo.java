public class MathDemo {
    public static void main(String[] args) {
        System.out.println(Math.abs(-12.7));
        System.out.println(Math.ceil(12.7));
        System.out.println(Math.rint(12.4));
        System.out.println(Math.random());
        System.out.println("sin30="+Math.PI/6);
        System.out.println("cos30 = " + Math.cos(Math.PI / 6));
        System.out.println("tan30 = " + Math.tan(Math.PI / 6));
    }
}