public abstract class TelePhone {
    public abstract void call();
    public abstract void message();
}
