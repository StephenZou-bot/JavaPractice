import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.FileAlreadyExistsException;

public class ThrowsTest {
    public static void main(String[] args) throws FileNotFoundException {
        throwsTest();
    }

    public static void throwsTest() throws FileNotFoundException{
        new FileInputStream("/home/stephenzou/文档/my fifth java/src");
    }
}
